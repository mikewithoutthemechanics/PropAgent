module.exports=[3511,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_tenants_page_actions_0~ovqoi.js.map