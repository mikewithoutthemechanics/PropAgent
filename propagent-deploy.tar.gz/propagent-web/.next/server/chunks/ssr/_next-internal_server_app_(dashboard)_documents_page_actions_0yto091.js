module.exports=[77275,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_documents_page_actions_0yto091.js.map