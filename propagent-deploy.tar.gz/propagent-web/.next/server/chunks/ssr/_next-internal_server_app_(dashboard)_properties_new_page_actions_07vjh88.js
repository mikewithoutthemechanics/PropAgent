module.exports=[66900,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_properties_new_page_actions_07vjh88.js.map