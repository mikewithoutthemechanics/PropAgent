module.exports=[76921,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_escrow_page_actions_0qcbx8e.js.map