module.exports=[68897,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_pricing_page_actions_0tvxqfb.js.map