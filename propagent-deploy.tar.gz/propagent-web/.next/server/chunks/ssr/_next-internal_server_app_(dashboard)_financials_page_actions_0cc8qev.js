module.exports=[5081,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_financials_page_actions_0cc8qev.js.map