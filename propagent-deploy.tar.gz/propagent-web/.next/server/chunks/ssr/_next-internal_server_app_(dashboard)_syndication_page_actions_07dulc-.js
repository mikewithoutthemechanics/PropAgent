module.exports=[56917,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_syndication_page_actions_07dulc-.js.map