module.exports=[92219,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_rankings_page_actions_019i4rb.js.map