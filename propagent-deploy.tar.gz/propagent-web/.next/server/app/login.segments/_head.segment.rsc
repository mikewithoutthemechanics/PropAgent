1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/02m~~mso0cxqh.js","/_next/static/chunks/0ukij9-gdz4jk.js","/_next/static/chunks/00-csyj9a6t-x.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/02m~~mso0cxqh.js","/_next/static/chunks/0ukij9-gdz4jk.js","/_next/static/chunks/00-csyj9a6t-x.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/02m~~mso0cxqh.js","/_next/static/chunks/0ukij9-gdz4jk.js","/_next/static/chunks/00-csyj9a6t-x.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"PropAgent - Authentication"}],["$","meta","1",{"name":"description","content":"Sign in or create your account"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0x3dzn~oxb6tn.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"MecFM9ZXa-i9X8WZnauuP"}
