globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/MecFM9ZXa-i9X8WZnauuP/_buildManifest.js",
    "static/MecFM9ZXa-i9X8WZnauuP/_ssgManifest.js",
    "static/MecFM9ZXa-i9X8WZnauuP/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/16fce0~0kfr7_.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0h4bq73pogmtb.js",
    "static/chunks/0vjl2odh~7nce.js",
    "static/chunks/turbopack-0yhgssse_o68-.js"
  ]
};
